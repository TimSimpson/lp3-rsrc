# Moby Wha?

The file 2701-0.txt came from Project Gutenberg and is public domain.
For info, visit

    https://www.gutenberg.org/ebooks/2701
